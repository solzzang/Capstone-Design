package com.mystes.mytraineragain;


import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.MediaController;
import android.widget.VideoView;


/**
 * Created by lasiy on 2017-05-24.
 */

public class YouthSportsActivity_bycle extends AppCompatActivity {

   VideoView vv_bycle;
   @Override
    protected void onCreate(Bundle saveInstanceState) {
       super.onCreate(saveInstanceState);
       setContentView(R.layout.sports_mv_youth_bycle);

       vv_bycle = (VideoView) findViewById(R.id.vv_bycle);
       Uri videoUri = Uri.parse("http://nfa.kspo.or.kr/common/site/www/front/movie_zip/452/452.mp4");

       vv_bycle.setMediaController(new MediaController(this));

       vv_bycle.setVideoURI(videoUri);

       vv_bycle.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
           @Override
           public void onPrepared(MediaPlayer mediaPlayer) {
               vv_bycle.start();
           }
       });
   }

       @Override
           protected void onPause() {
           super.onPause();

           if(vv_bycle!=null && vv_bycle.isPlaying()) vv_bycle.pause();
       }
       @Override
       protected void onDestroy() {
           super.onDestroy();
           if(vv_bycle!=null)vv_bycle.stopPlayback();
       }
   }
