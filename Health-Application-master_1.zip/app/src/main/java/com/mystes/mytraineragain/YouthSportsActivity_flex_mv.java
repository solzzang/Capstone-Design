package com.mystes.mytraineragain;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;


/**
 * Created by lasiy on 2017-05-24.
 */

public class YouthSportsActivity_flex_mv extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sports_mv_youth_flex);
        //개발자 정보 버튼 클릭시 액티비티 전환
        Button neck_stretching_btn = (Button) findViewById(R.id.neck_stretching);
        neck_stretching_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), YouthSportsActivity_neck.class);
                startActivity(intent);
            }
        });
        Button chest_stretching_btn = (Button) findViewById(R.id.chest_stretching);
        chest_stretching_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), YouthSportsActivity_chest.class);
                startActivity(intent);
            }
        });
        Button trunk_twist_btn = (Button) findViewById(R.id.trunk_twist);
        trunk_twist_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), YouthSportsActivity_trunk.class);
                startActivity(intent);
            }
        });
        Button total_body_stretching_btn = (Button) findViewById(R.id.total_body_stretching);
        total_body_stretching_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), YouthSportsActivity_total_body.class);
                startActivity(intent);
            }
        });
    }
}
