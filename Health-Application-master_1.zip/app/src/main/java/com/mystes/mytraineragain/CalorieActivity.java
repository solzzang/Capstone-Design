package com.mystes.mytraineragain;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;


/**
 * Created by lasiy on 2017-05-24.
 */

public class CalorieActivity extends AppCompatActivity {

    final static String TAG ="XML";
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calorie);

        listView = (ListView) findViewById(R.id.listView);

        ArrayList<Food> list = parser();
        String[] data = new String[list.size()]; // ArrayList 크기만큼 배열 할당

        for(int i = 0; i < list.size(); i++){
            data[i] = list.get(i).getName()+" "+list.get(i).getCalorie();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_1, data);
        listView.setAdapter(adapter);
    }

    private ArrayList<Food> parser(){
        Log.i(TAG, "parser()");
        ArrayList<Food> arrayList = new ArrayList<Food>();

        // 내부 xml파일이용시
        InputStream inputStream = getResources().openRawResource(R.raw.food);
        InputStreamReader inputStreamReader = new InputStreamReader(inputStream);

        XmlPullParserFactory factory = null;
        XmlPullParser xmlParser = null;

        try {
            factory = XmlPullParserFactory.newInstance();
            xmlParser = factory.newPullParser();
            xmlParser.setInput(inputStreamReader);
            Food food = null;

            int eventType = xmlParser.getEventType();

            while (eventType != XmlPullParser.END_DOCUMENT){
                switch (eventType){
                    case XmlPullParser.START_DOCUMENT:
                        Log.i(TAG, "xml START");
                        break;
                    case XmlPullParser.START_TAG:
                        Log.i(TAG, "Start TAG :" + xmlParser.getName());
                        try {
                            String startTag = xmlParser.getName();
                            if(startTag.equals("food")){
                                food = new Food();
                            }
                            if(startTag.equals("name")){
                                food.setName(xmlParser.nextText());
                                Log.i(TAG,"TEXT : "+ xmlParser.getText());
                                Log.i(TAG,"TEXT : "+ xmlParser.getName());
                                Log.i(TAG,"TEXT : "+ food.getName());
                            }
                            if(startTag.equals("calorie")){
                                food.setCalorie(xmlParser.nextText());
                                Log.i(TAG,"TEXT : "+ xmlParser.getName());
                                Log.i(TAG,"TEXT : "+ xmlParser.getName());
                                Log.i(TAG,"TEXT : "+ food.getCalorie());
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        Log.i(TAG,"End TAG : "+ xmlParser.getName());
                        String endTag = xmlParser.getName();
                        if(endTag.equals("food")){
                            arrayList.add(food);
                        }
                        break;
                }
                try {
                    eventType = xmlParser.next();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } finally{
            try{
                if(inputStreamReader !=null) inputStreamReader.close();
                if(inputStream !=null) inputStream.close();
            }catch(Exception e2){
                e2.printStackTrace();
            }
        }
        return arrayList;
    }
}
