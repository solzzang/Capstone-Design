package com.mystes.mytraineragain;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

/**
 * Created by lasiy on 2017-05-24.
 */

public class AgainActivity extends AppCompatActivity implements View.OnClickListener {
    static String msg;
    static String[] exerList;
    static int[] layoutList;

    TextView exercise_view;
    Button Progarm_btn, btn_calorie, btn_guide;
    AlarmManager mAlarmMgr;

    Button[] exerBtn = new Button[6];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        /* 버튼 선언 */
        Progarm_btn = (Button) findViewById(R.id.btn_program);
        btn_calorie = (Button) findViewById(R.id.btn_calorie);
        btn_guide = (Button) findViewById(R.id.btn_guide);
        exercise_view = (TextView) findViewById(R.id.main_text);

        exerBtn[0] = (Button) findViewById(R.id.btn_exerA);
        exerBtn[1] = (Button) findViewById(R.id.exerA_moer);

        exerBtn[2] = (Button) findViewById(R.id.btn_exerB);
        exerBtn[3] = (Button) findViewById(R.id.exerB_more);

        exerBtn[4] = (Button) findViewById(R.id.btn_exerC);
        exerBtn[5] = (Button) findViewById(R.id.exerC_more);


        /* 프로그램 액티비티 출력 */
        Progarm_btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), BMIActivity.class);
                startActivity(intent);
            }
        });

        /* 앱 소개 화면 출력 */
        btn_guide.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), SportsActivity_youth.class);
                startActivity(intent);
            }
        });

        btn_calorie.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), CalorieActivity.class);
                startActivity(intent);
            }
        });

        Intent pintent = this.getIntent();  // 프로그램 선택에서 넘어온 intent 받기
        msg = pintent.getStringExtra("msg");

        // 프로그램별 다른 버튼 text 출력을 위한 기능
        if (msg != null) {
            exerList = getIntent().getStringArrayExtra("exerList");
            layoutList = getIntent().getIntArrayExtra("layoutList");
            for (int i = 0; i < 6; i++) {
                if ((i % 2) == 0)
                    exerBtn[i].setText(exerList[i]);
                exerBtn[i].setTag(i);
                exerBtn[i].setOnClickListener(this);
            }
        }
    }

    @Override
    public void onClick(View v) {
        Button btn = (Button) v;

        for(Button tmpBtn : exerBtn) {
            if (tmpBtn == btn) {
                final int s = (Integer) v.getTag();

                try {
                    if( (s % 2) == 0) {
                        try {
                            exercise_view.setText(exerList[s + 1]);    // 운동버튼 A 클릭시 textView에 정보 출력
                        } catch (NumberFormatException e) {
                            exercise_view.setText("운동 정보 없음");
                        }
                    }
                    else {
                        try {
                            Context mContext = getApplicationContext(); // 현재 앱의 context를 가져온다

                            //레이아웃 플레터를 통해 팝업 창 구현
                            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);

                            // 팝업을 띄울 layout 설정
                            View layout = inflater.inflate(layoutList[s / 2], (ViewGroup) findViewById(R.id.exerPopup));
                            AlertDialog.Builder aDialog = new AlertDialog.Builder(AgainActivity.this);

                            aDialog.setView(layout);   // 출력할 뷰를 위에 설정한 layout으로 설정

                            AlertDialog ad = aDialog.create();
                            ad.show();      // 팝업 출력
                        } catch (Exception e) {
                            Toast.makeText(getApplication(), "부연설명 없음",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                } catch (Exception e) {
                    Toast.makeText(getApplication(), "click Error", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

}

