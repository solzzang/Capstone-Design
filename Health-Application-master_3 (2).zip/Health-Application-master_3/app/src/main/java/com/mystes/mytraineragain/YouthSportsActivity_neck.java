package com.mystes.mytraineragain;


import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.MediaController;
import android.widget.VideoView;


/**
 * Created by lasiy on 2017-05-24.
 */

public class YouthSportsActivity_neck extends AppCompatActivity {

   VideoView vv_neck;
   @Override
    protected void onCreate(Bundle saveInstanceState) {
       super.onCreate(saveInstanceState);
       setContentView(R.layout.sports_mv_youth_neck);

       vv_neck = (VideoView) findViewById(R.id.vv_neck);
       Uri videoUri = Uri.parse("http://nfa.kspo.or.kr/common/site/www/front/movie_zip/576/576.mp4");

       vv_neck.setMediaController(new MediaController(this));

       vv_neck.setVideoURI(videoUri);

       vv_neck.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
           @Override
           public void onPrepared(MediaPlayer mediaPlayer) {
               vv_neck.start();
           }
       });
   }

       @Override
           protected void onPause() {
           super.onPause();

           if(vv_neck!=null && vv_neck.isPlaying()) vv_neck.pause();
       }
       @Override
       protected void onDestroy() {
           super.onDestroy();
           if(vv_neck!=null)vv_neck.stopPlayback();
       }
   }
