package com.mystes.mytraineragain;


import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.MediaController;
import android.widget.VideoView;


/**
 * Created by lasiy on 2017-05-24.
 */

public class YouthSportsActivity_run extends AppCompatActivity {

   VideoView vv_run;
   @Override
    protected void onCreate(Bundle saveInstanceState) {
       super.onCreate(saveInstanceState);
       setContentView(R.layout.sports_mv_youth_run);

       vv_run = (VideoView) findViewById(R.id.vv_run);
       Uri videoUri = Uri.parse("http://nfa.kspo.or.kr/common/site/www/front/movie_zip/451/451.mp4");

       vv_run.setMediaController(new MediaController(this));

       vv_run.setVideoURI(videoUri);

       vv_run.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
           @Override
           public void onPrepared(MediaPlayer mediaPlayer) {
               vv_run.start();
           }
       });
   }

       @Override
           protected void onPause() {
           super.onPause();

           if(vv_run!=null && vv_run.isPlaying()) vv_run.pause();
       }
       @Override
       protected void onDestroy() {
           super.onDestroy();
           if(vv_run!=null)vv_run.stopPlayback();
       }
   }
