package com.mystes.mytraineragain;


import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.MediaController;
import android.widget.VideoView;


/**
 * Created by lasiy on 2017-05-24.
 */

public class YouthSportsActivity_situp extends AppCompatActivity {

   VideoView vv_situp;
   @Override
    protected void onCreate(Bundle saveInstanceState) {
       super.onCreate(saveInstanceState);
       setContentView(R.layout.sports_mv_youth_situp);

       vv_situp = (VideoView) findViewById(R.id.vv_situp);
       Uri videoUri = Uri.parse("http://nfa.kspo.or.kr/common/site/www/front/movie_zip/479/479.mp4");

       vv_situp.setMediaController(new MediaController(this));

       vv_situp.setVideoURI(videoUri);

       vv_situp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
           @Override
           public void onPrepared(MediaPlayer mediaPlayer) {
               vv_situp.start();
           }
       });
   }

       @Override
           protected void onPause() {
           super.onPause();

           if(vv_situp!=null && vv_situp.isPlaying()) vv_situp.pause();
       }
       @Override
       protected void onDestroy() {
           super.onDestroy();
           if(vv_situp!=null)vv_situp.stopPlayback();
       }
   }
