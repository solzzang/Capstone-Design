package com.mystes.mytraineragain;


import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.MediaController;
import android.widget.VideoView;


/**
 * Created by lasiy on 2017-05-24.
 */

public class YouthSportsActivity_walk extends AppCompatActivity {

   VideoView vv_walking;
   @Override
    protected void onCreate(Bundle saveInstanceState) {
       super.onCreate(saveInstanceState);
       setContentView(R.layout.sports_mv_youth_walking);

       vv_walking = (VideoView) findViewById(R.id.vv_walking);
       Uri videoUri = Uri.parse("http://nfa.kspo.or.kr/common/site/www/front/movie_zip/450/450.mp4");

       vv_walking.setMediaController(new MediaController(this));

       vv_walking.setVideoURI(videoUri);

       vv_walking.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
           @Override
           public void onPrepared(MediaPlayer mediaPlayer) {
               vv_walking.start();
           }
       });
   }

       @Override
           protected void onPause() {
           super.onPause();

           if(vv_walking!=null && vv_walking.isPlaying()) vv_walking.pause();
       }
       @Override
       protected void onDestroy() {
           super.onDestroy();
           if(vv_walking!=null)vv_walking.stopPlayback();
       }
   }
