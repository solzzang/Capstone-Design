package com.mystes.mytraineragain;


import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.MediaController;
import android.widget.VideoView;


/**
 * Created by lasiy on 2017-05-24.
 */

public class YouthSportsActivity_sitandstand extends AppCompatActivity {

   VideoView vv_sitandstand;
   @Override
    protected void onCreate(Bundle saveInstanceState) {
       super.onCreate(saveInstanceState);
       setContentView(R.layout.sports_mv_youth_sitandstand);

       vv_sitandstand = (VideoView) findViewById(R.id.vv_sitandstand);
       Uri videoUri = Uri.parse("http://nfa.kspo.or.kr/common/site/www/front/movie_zip/483/483.mp4");

       vv_sitandstand.setMediaController(new MediaController(this));

       vv_sitandstand.setVideoURI(videoUri);

       vv_sitandstand.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
           @Override
           public void onPrepared(MediaPlayer mediaPlayer) {
               vv_sitandstand.start();
           }
       });
   }

       @Override
           protected void onPause() {
           super.onPause();

           if(vv_sitandstand!=null && vv_sitandstand.isPlaying()) vv_sitandstand.pause();
       }
       @Override
       protected void onDestroy() {
           super.onDestroy();
           if(vv_sitandstand!=null)vv_sitandstand.stopPlayback();
       }
   }
