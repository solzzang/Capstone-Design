package com.mystes.mytraineragain;


import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.MediaController;
import android.widget.VideoView;


/**
 * Created by lasiy on 2017-05-24.
 */

public class YouthSportsActivity_total_body extends AppCompatActivity {

   VideoView vv_total_body;
   @Override
    protected void onCreate(Bundle saveInstanceState) {
       super.onCreate(saveInstanceState);
       setContentView(R.layout.sports_mv_youth_total_body);

       vv_total_body = (VideoView) findViewById(R.id.vv_total_body);
       Uri videoUri = Uri.parse("http://nfa.kspo.or.kr/common/site/www/front/movie_zip/597/597.mp4");

       vv_total_body.setMediaController(new MediaController(this));

       vv_total_body.setVideoURI(videoUri);

       vv_total_body.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
           @Override
           public void onPrepared(MediaPlayer mediaPlayer) {
               vv_total_body.start();
           }
       });
   }

       @Override
           protected void onPause() {
           super.onPause();

           if(vv_total_body!=null && vv_total_body.isPlaying()) vv_total_body.pause();
       }
       @Override
       protected void onDestroy() {
           super.onDestroy();
           if(vv_total_body!=null)vv_total_body.stopPlayback();
       }
   }
