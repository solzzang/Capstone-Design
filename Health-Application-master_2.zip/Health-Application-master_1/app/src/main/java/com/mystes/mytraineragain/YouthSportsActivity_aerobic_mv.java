package com.mystes.mytraineragain;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;


/**
 * Created by lasiy on 2017-05-24.
 */

public class YouthSportsActivity_aerobic_mv extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sports_mv_youth_aerobic);
        //개발자 정보 버튼 클릭시 액티비티 전환
        Button run_btn = (Button) findViewById(R.id.run);
        run_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), YouthSportsActivity_run.class);
                startActivity(intent);
            }
        });
        Button walking_btn = (Button) findViewById(R.id.walking);
        walking_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), YouthSportsActivity_walk.class);
                startActivity(intent);
            }
        });
        Button swim_btn = (Button) findViewById(R.id.swim);
        swim_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), YouthSportsActivity_swim.class);
                startActivity(intent);
            }
        });
        Button bycle_btn = (Button) findViewById(R.id.bycle);
        bycle_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), YouthSportsActivity_bycle.class);
                startActivity(intent);
            }
        });
    }
}
