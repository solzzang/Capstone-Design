package com.mystes.mytraineragain;


import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.MediaController;
import android.widget.VideoView;


/**
 * Created by lasiy on 2017-05-24.
 */

public class YouthSportsActivity_trunk extends AppCompatActivity {

   VideoView vv_trunk;
   @Override
    protected void onCreate(Bundle saveInstanceState) {
       super.onCreate(saveInstanceState);
       setContentView(R.layout.sports_mv_youth_trunk);

       vv_trunk = (VideoView) findViewById(R.id.vv_trunk);
       Uri videoUri = Uri.parse("http://nfa.kspo.or.kr/common/site/www/front/movie_zip/579/579.mp4");

       vv_trunk.setMediaController(new MediaController(this));

       vv_trunk.setVideoURI(videoUri);

       vv_trunk.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
           @Override
           public void onPrepared(MediaPlayer mediaPlayer) {
               vv_trunk.start();
           }
       });
   }

       @Override
           protected void onPause() {
           super.onPause();

           if(vv_trunk!=null && vv_trunk.isPlaying()) vv_trunk.pause();
       }
       @Override
       protected void onDestroy() {
           super.onDestroy();
           if(vv_trunk!=null)vv_trunk.stopPlayback();
       }
   }
