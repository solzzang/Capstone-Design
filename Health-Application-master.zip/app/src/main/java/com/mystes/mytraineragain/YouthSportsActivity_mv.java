package com.mystes.mytraineragain;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;


/**
 * Created by lasiy on 2017-05-24.
 */

public class YouthSportsActivity_mv extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sports_mv_youth);
        //개발자 정보 버튼 클릭시 액티비티 전환
        Button youth_btn = (Button) findViewById(R.id.run);
        youth_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), YouthSportsActivity_run.class);
                startActivity(intent);
            }
        });
    }
}
